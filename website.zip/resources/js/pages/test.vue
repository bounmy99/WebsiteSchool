<template>
    <div>
        <p>Test Pages</p>
    </div>
</template>

<script>
export default {
    name: 'WorkspaceJsonTest',

    data() {
        return {
            
        };
    },

    mounted() {
        
    },

    methods: {
        
    },
};
</script>

<style lang="scss" scoped>

</style>