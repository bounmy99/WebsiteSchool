
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Haakkeo Secondary School</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../../assetss/img/logo.gif" rel="icon">
  <link href="../../assetss/img/logo.gif" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../../assetss/vendor/aos/aos.css" rel="stylesheet">
  <link href="../../assetss/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../assetss/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../../assetss/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../../assetss/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../../assetss/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../../assetss/datatables.net-dt/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="../../assetss/datatables.net-dt/js/dataTables.min.css">

  <!-- Template Main CSS File -->
  <link href="../../assetss/css/style.css" rel="stylesheet">
  <link
    href="https://fonts.googleapis.com/css2?family=Noto+Sans+Lao:wght@100;200;300;400;500;600;700;800;900&display=swap"
    rel="stylesheet">
  <script src="https://cdn.ckeditor.com/ckeditor5/38.0.1/classic/ckeditor.js"></script>
  <style>
    body,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    span {
      font-family: 'Noto Sans Lao', sans-serif;
      font-weight: 600;
    }
  </style>
  <!-- =======================================================
  * Template Name: BizLand - v3.8.1
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">
      <a href="index.html">
        <img src="../../assetss/img/logo.gif" width="50px" height="50px" alt="">
      </a>
      <h1 style="text-shadow:3px 3px rgb(243, 238, 175);">
        <marquee behavior="" direction="left">
          <a href="index.html">
            <span>Haakkeo News 04</span>
          </a>
        </marquee>
      </h1>
      <!-- ພາກສ່ວນເມນູຕ່າງໆ -->
      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">ເມນູຫຼັກ</a></li>
          <li><a class="nav-link scrollto" href="#new">ກອງຂ່າວສານແລະສື່ສານ</a></li>
          <li><a class="nav-link scrollto " href="#activate">ກິດຈະກຳ</a></li>

          <li class="dropdown"><a href="#"><span>ຊົມລົມ </span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li class="dropdown"><a href="#"><span>ຊົມລົມກິລາ</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a class="nav-link scrollto" href="#football">ກິລາບານເຕະ</a></li>
                  <li><a class="nav-link scrollto" href="#volleyball">ກິລາບານສົ່ງ</a></li>
                  <li><a class="nav-link scrollto" href="#basketball">ກິລາບານບ້ວງ</a></li>
                </ul>
              </li>
              <li><a class="nav-link scrollto" href="#food">ຊົມລົມອາຫານ</a></li>
              <li><a class="nav-link scrollto" href="#create">ຊົມລົມປະດິດ</a></li>
              <li><a class="nav-link scrollto" href="#evronment">ຊົມລົມສິ່ງແວດລ້ອມ</a></li>
              <li><a class="nav-link scrollto" href="#dance">ຊົມລົມເຕັ້ນ</a></li>
              <li><a class="nav-link scrollto" href="#music">ຊົມລົມດົນຕຣີ</a></li>
              <li><a class="nav-link scrollto" href="#drawing">ຊົມລົມແຕ້ມຮູບ</a></li>
              <li><a class="nav-link scrollto" href="#PD">ຊົມລົມຖ່າຍຮູບແລະໂຕ້ວາທີ</a></li>
              <li><a class="nav-link scrollto" href="#Haakkeo Sound Crew">Haakkeo Sound Crew</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>ສິ່ງທີ່ໜ້າສົນໃຈ</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a class="nav-link scrollto" href="#m5">ຄົນດີຂອງໝູ່</a></li>
              <li><a class="nav-link scrollto" href="#m6">ຄົນດີຮຽນເກັ່ງ</a></li>
              <li><a class="nav-link scrollto" href="#m7">ຂໍຄວາມຮ່ວມມື</a></li>
              <li><a class="nav-link scrollto" href="#m8">ຊຸບຊິບສັງຄົມ</a></li>
              <li><a class="nav-link scrollto" href="#m9">ແຂກທີ່ມາຢ້ຽມຢາມ</a></li>
            </ul>
          </li>
          </li>
          <li><a class="nav-link scrollto" href="#contact">ການຕິດຕໍ່</a></li>
          <li><a class="nav-link scrollto" href="<?php echo e(url('/login')); ?>">ເຂົ້າສູ່ລະບົບ</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>
  <section id="hero" style="background-image: url('../../assetss/img/background.jpeg');
    width: 100%;
    height: 75vh;
    background-size: cover;
    position: relative;">
    <div class="d-flex align-items-center">
      <div class="container aos-init aos-animate text-center" data-aos="zoom-out" data-aos-delay="100">
        <img src="../../assetss/img/logo.gif" alt="" width="200" height="200">

        <h1 style="text-shadow:3px 3px rgb(243, 238, 175); margin-top: 5rem;">
          <span>Haakkeo Secondary School</span>
        </h1>

      </div>
    </div>
  </section><!-- End Hero -->
  <main id="main">
  <?php echo e($data); ?>

    <!-- ພາກສ່ວນຂ່າວສານ -->
    <section id="new" class="a1.jpg section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h3><span>ຂໍ້ມູນຂ່າວສານຂອງໂຮງຮຽນ</span></h3>
        </div>
        <div class="row">
          <div class="col-sm-12 my-1">

                <div class="editor">
              <?php echo e($data); ?>

                  <p class="card-text">
                  <h5 class="card-title">ທີມຂ່າວສານ</h5>
                    ຊົມລົມປະຊາສໍາພັນ-ຂ່າວ ເປັນສິ່ງຈໍາເປັນທີ່ຕ້ອງເຮັດຕ້ອງມີ,
                    ເພາະເປັນວິທີໜຶ່ງທີ່ຈະໃຫ້ເກີດຄວາມສໍາພັນອັນດີລະຫວ່າງນັກຮຽນດ້ວຍກັນ ,ນັກຮຽນກັບຄູ ແລະ ຜູ້ປົກຄອງ
                    ເພື່ອໃຫ້ທຸກຄົນໄດ້ຮັບຮູ້ເລື່ອງລາວຕ່າງໆ ຂອງໂຮງຮຽນ ແລະໃຫ້ມີການສະໝັບສະໜູນ ຮ່ວມມືຊ່ວຍເຫຼຶອເຊິ່ງກັນແລະກັນ.
                    <li>ຊົມລົມປະຊາສໍາພັນ -ຂ່າວ</li>
                    <li>ວິໄສທັດ “ ເປັນສື່ກາງ ເພື່ອສ້າງມິດຕະພາບ ແຮງບັນດານໃຈ ໃຫ້ໝູ່ເພື່ອນ “</li>
              
                  <h5 class="card-title">ພັນທະກິດ </h5>
                  <ol type="1">
                    <li> ເຜີຍແຜ່ຂໍ້ມູນຂ່າວສານຕ່າງໆຂອງໂຮງຮຽນ</li>
                    <li> ເສີມສ້າງຄວາມສໍາພັນອັນດີ ລະຫວ່າງຄູ-ນັກຮຽນແລະນັກຮຽນດ້ວຍກັນ</li>
                    <li>ເສີມສ້າງຄວາມເຂົ້າໃຈອັນດີ ລະຫວ່າງໂຮງຮຽນກັບຜູ້ປົກຄອງ</li>
                    <li>ເປັນບ່ອນປະກາດຍົກຍ່ອງ ເຊີດຊູ ກິດຈະກໍາຜົນງານທີ່ຄູ ແລະ ນັກຮຽນທີ່ເຮັດໄດ້ດີໃຫ້ທຸກຄົນຮັບຮູ້</li>
                  </ol>
                  <h5 class="card-title">ກົນລະຍຸດ : </h5>
                  <ol type="1">
                    <li>ບໍລິການ ແລະ ພັດທະນາລະບົບການສື່ສານ ໃນການປະຊາສໍາພັນ ໂດຍໃຊ້ເທັກໂນໂລຊີທັນສະໄໝ ໄດ້
                      ມາດຕະຖານສາກົນ</li>
                    <li> ປະຊາສໍາພັນໃຫ້ມີການຮ່ວມມືທີ່ດີລະຫວ່າງຜູ້ປົກຄອງແລະໂຮງຮຽນ</li>
                    <li> ແນະນໍາວຽກງານ ກິດຈະກໍາການເຄື່ອນໄຫວຕ່າງໆພາຍໃນແລະນອກໂຮງຮຽນໃຫ້ຄູ-
                      ນັກຮຽນ ແລະ ຜູ້ປົກຄອງຮູ້ ທຸກໆເດືອນ.
                    </li>
                  </ol>
                  </p>
                  <hr>
                  <h5 class="card-title">ການປະກາດແຈ້ງການ</h5>
                  <p class="card-text">
                  <ol type="">
                    <li>ໃນວັນທີ່ 01/05 ເຮົາຈະໄດ້ພັກເນື່ອງໃນໂອກາດວັນກຳມະກອນ ແລະ ຈະເຂົ້າຮຽນຕາມປົກກະຕິໃນມື້ຕໍ່ໄປ</li>
                    <li>ໃນວັນທີ່ 22 - 24 /05/2023 ແມ່ນທາງໂຮງຮຽນຈະໄດ້ທຳການເສັງພາກຮຽນສອງ</li>                  
                  </ol>
                  </p>
                  <h5 class="card-title">ກິດຈະກຳພາຍໃນເດຶອນນີ້</h5>
                  <p class="card-text">
                  <ol type="">
                    <li>ວັນທີ08/04 ແລະ 10/04 ແມ່ນທາງໂຮງຮຽນເຮົາມີງານກິດຈະກຳ,ງານສະແດງຂອງນັກຮຽນຕັ້ງອະນຸບານ ຈົນຮອດມັດທະຍົມຕອນປາຍ.</li>
                    <li>ວັນທີ່11/04 ທາງໂຮງຮຽນມີກິດຈະກຳບາສີສູ່ຂວັນໃນຕອນເຊົ່າ ແລະ ຕອນສວາຍຫລັງຈາກກີນເຂົ້າແມ່ນຫລິ້ນນ້ຳ</li>
                    <li>ວັນທີ່ 12/04 - 18/04 ແມ່ນເຮົາຈະໄດ້ພັກປີໃຫມ່ລາວ</li>
                  </ol>
                  </p>
                </div>
          </div>
        </div>
      </div>
    </section>
    <!-- ພາກສ່ວນກິດຈະກຳ -->
    <section id="activate" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h3><span>ກິດຈະກຳ</span></h3>
        </div>
        <h3>
           1.ພາບບັນຍາກາດຫຼີ້ນບຸນປີໃໝ່ລາວຂອງນັກຮຽນ ແລະ ຄູອາຈານ
        </h3>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b1.jpg" target="_blank">
                <img src="../../assetss/img/activity/b1.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b2.jpg" target="_blank">
                <img src="../../assetss/img/activity/b2.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b3.jpg" target="_blank">
                <img src="../../assetss/img/activity/b3.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b4.jpg" target="_blank">
                <img src="../../assetss/img/activity/b4.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b5.jpg" target="_blank">
                <img src="../../assetss/img/activity/b5.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b6.jpg" target="_blank">
                <img src="../../assetss/img/activity/b6.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b7.jpg" target="_blank">
                <img src="../../assetss/img/activity/b7.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b8.jpg" target="_blank">
                <img src="../../assetss/img/activity/b8.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b9.jpg" target="_blank">
                <img src="../../assetss/img/activity/b9.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b10.jpg" target="_blank">
                <img src="../../assetss/img/activity/b10.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b11.jpg" target="_blank">
                <img src="../../assetss/img/activity/b11.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/b12.jpg" target="_blank">
                <img src="../../assetss/img/activity/b12.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div>
          </div>

          
      </div>
        <h3>
          2.ລວມຮູບພາບບັນຍາກາດການເດີນທາງ ແລະ ເຮັດກິດຈະກຳສັງສິນໄຊ
        </h3>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/a1.jpg" target="_blank">
                <img src="../../assetss/img/activity/a1.jpg" alt="" class="mx-2 my-2"
                  style="width:315px; height:200px; margin-top: 15px; ">
              </a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/a2.jpg" target="_blank">
                <img src="../../assetss/img/activity/a2.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px; ">
              </a>

              </div>
            </div> 


          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/a3.jpg" target="_blank">
                <img src="../../assetss/img/activity/a3.jpg" alt="" class="mx-2 mb-2"
                   style="width: 315px; height:200px; margin-top: 15px; ">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/a4.jpg" target="_blank">
                <img src="../../assetss/img/activity/a4.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px; ">
              </a>

             </div> 
            </div> 

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/a5.jpg" target="_blank">
                <img src="../../assetss/img/activity/a5.jpg" alt="" class="mx-2 mb-2"
                   style="width:315px; height:200px; margin-top: 15px; ">
              </a>
              
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/a6.jpg" target="_blank">
                <img src="../../assetss/img/activity/a6.jpg" alt="" class="mx-2 mb-2"
                   style="width:315px; height:200px; margin-top: 15px; ">
              </a>
              
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/a7.jpg" target="_blank">
                <img src="../../assetss/img/activity/a7.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px; ">
              </a>

             </div> 
            </div> 

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/a8.jpg" target="_blank">
                <img src="../../assetss/img/activity/a8.jpg" alt="" class="mx-2 mb-2"
                   style="width:315px; height:200px; margin-top: 15px; ">
              </a>
              
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/a9.jpg" target="_blank">
                <img src="../../assetss/img/activity/a9.jpg" alt="" class="mx-2 mb-2"
                   style="width:315px; height:200px; margin-top: 15px; ">
              </a>
              
            </div>
          </div>
        
        </div>
        <h3>
          3. ຮູບພາບບັນຍາກາດການບາສີສູ່ຂວັນຂອງນັກຮຽນ ແລະ ຄູອາຈານ ທັງອານຸບານ,ປະຖົມ ແລະ ມັດທະຍົມ
        </h3>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/t1.jpg" target="_blank">
                <img src="../../assetss/img/activity/t1.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/t2.jpg" target="_blank">
                <img src="../../assetss/img/activity/t2.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/t3.jpg" target="_blank">
                <img src="../../assetss/img/activity/t3.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/t4.jpg" target="_blank">
                <img src="../../assetss/img/activity/t4.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/t5.jpg" target="_blank">
                <img src="../../assetss/img/activity/t5.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/t6.jpg" target="_blank">
                <img src="../../assetss/img/activity/t6.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/t7.jpg" target="_blank">
                <img src="../../assetss/img/activity/t7.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/t8.jpg" target="_blank">
                <img src="../../assetss/img/activity/t8.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/t9.jpg" target="_blank">
                <img src="../../assetss/img/activity/t9.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>
        </div>
        <h3>
          4. ຮູບພາບບັນຍາກາດການການຟ້ອນລຳຂອງຄູອາຈານ
        </h3>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/d1.jpg" target="_blank">
                <img src="../../assetss/img/activity/d1.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/d2.jpg" target="_blank">
                <img src="../../assetss/img/activity/d2.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/d3.jpg" target="_blank">
                <img src="../../assetss/img/activity/d3.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/d4.jpg" target="_blank">
                <img src="../../assetss/img/activity/d4.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/d5.jpg" target="_blank">
                <img src="../../assetss/img/activity/d5.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/d6.jpg" target="_blank">
                <img src="../../assetss/img/activity/d6.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>
          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/activity/d7.jpg" target="_blank">
                <img src="../../assetss/img/activity/d7.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/d8.jpg" target="_blank">
                <img src="../../assetss/img/activity/d8.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-sport">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/activity/d9.jpg" target="_blank">
                <img src="../../assetss/img/activity/d9.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div>
        </div>
    </section>
        <!--ພາກສ່ວນຮູບສະໄລ  -->

        <section id="portfolio-details" class="portfolio-details">
      <div class="container">

        <div class="row gy-4">
          <!-- <div class="col-lg-12">
            <div class="section-title">
              <h3><span>ຮູບສະໄລໂຊ</span></h3>
            </div>
            <div id="demo" class="carousel slide" data-bs-ride="carousel">

              
              <div class="carousel-indicators">
                <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
                <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
                <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
              </div>

              
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="../../assetss/img/slideimage/s1.jpeg" alt="Los Angeles" class="d-block" style="width:100%;">
                </div>
                <div class="carousel-item">
                  <img src="../../assetss/img/slideimage/s2.jpg" alt="Chicago" class="d-block" style="width:100%;">
                </div>
                <div class="carousel-item">
                  <img src="../../assetss/img/slideimage/s3.jpg" alt="New York" class="d-block" style="width:100%;">
                </div>
              </div>

             
              <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
                <span class="carousel-control-prev-icon text-dark"></span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
                <span class="carousel-control-next-icon text-dark"></span>
              </button>
            </div>
          </div> -->
          <!-- <div class="col-lg-12">
            <div class="section-title">
              <h3><span>ວິດີໂອກິດຈະກຳ</span></h3>
            </div>
            <div>
              <video width="100%" height="100%" controls autoplay muted border="2">
              <source src="../../assetss/videos/v1.mp4" type="video/mp4" border="2">
              <source src="../../assetss/videos/v1.mp4" type="video/ogg">
            </video>
            </div>
            
            <div class="mt-2">
              <video width="100%" height="100%" controls autoplay muted border="2">
              <source src="../../assetss/videos/v3.mp4" type="video/mp4" border="2">
              <source src="../../assetss/videos/v3.mp4" type="video/ogg">
            </video>
            </div>
             
          </div> -->
        </div>

      </div>
    </section>

        <!-- ພາກສ່ວນຊົມລົມອາຫານ -->
        <section id="food" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <img src="../../assetss/img/food.jpeg" alt="" style="width: 10rem; height: 10rem;">
          <h3><span>ຊົມລົມອາຫານ</span></h3>
        </div>
        <div class="row">
          <div class="col-sm-12 my-1">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">
                  ບໍ່ມີການເຄື່ອນໄຫວ
               </h5>
              </div>
            </div>
          </div>
          <!-- <div class="col-sm-6 my-1">
            <div class="card">
              <div class="card-body">
                <div class="col-lg-12 my-3" data-aos="fade-right" data-aos-delay="100">
                  <video width="100%" height="100%" controls autoplay muted>
                    <source src="../../assetss/videos/" type="video/mp4" border="2">
                    <source src="../../assetss/videos/" type="video/ogg">
                  </video>
                </div>
              </div>
            </div>
          </div> -->
        </div>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/food/f1.jpeg" target="_blank">
                <img src="../../assetss/img/food/f1.jpeg" alt="" class="mx-2"
  mb-2"
  tyle="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div> -->
        </div>
      </div>
      </div>
    </section>

        <!-- ພາກສ່ວນຊົມລົມປະດິດ -->

        <section id="create" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <img src="../../assetss/img/create.jpeg" alt="" style="width: 10rem; height: 10rem;">
          <h3><span>ຊົມລົມປະດິດ</span></h3>
        </div>
        <div class="row">
          <div class="col-sm-12 my-1">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title"></h5>
                <h4>
                 ບໍ່ມີການເຄື່ອນໄຫວ
                </h4>
              </div>
            </div>
          </div>
        </div>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/created/1.1.jpg" target="_blank">
                <img src="../../assetss/img/created/1.1.jpg" alt="" class="mx-2 mb-2"
                  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div> -->
      </div>

      </div>

    </section>
        <!-- ພາກສ່ວນຊົມລົມສິ່ງແວດລ້ອມ -->
        <section id="evronment" class="portfolio">
          <div class="container" data-aos="fade-up">

            <div class="section-title">
              <img src="../../assetss/img/everonment.jpeg" alt="" style="width: 10rem; height: 10rem;">
              <h3><span>ຊົມລົມສິ່ງແວດລ້ອມ</span></h3>
            </div>
            <div class="row">
              <div class="col-sm-12 my-1">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title"></h5>
                    <h4>
                      ບໍ່ມີການເຄື່ອນໄຫວ
                    </h4>
                  </div>
                </div>
              </div>
               <div class="col-sm-6 my-1">
                  <!-- <div class="card">
                    <div class="card-body">
                      <div class="col-lg-12 my-3" data-aos="fade-right" data-aos-delay="100">
                        <video width="100%" height="100%" controls autoplay muted>
                          <source src="../../assetss/videos/3.mp4" type="video/mp4" border="2">
                          <source src="../../assetss/videos/3.mp4" type="video/ogg">
                        </video>
                      </div> 
                    </div>
                  </div> -->
              </div>
            </div>
            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

           <!--    <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/everonment/e1.JPG" target="_blank">
                    <img src="../../assetss/img/everonment/e1.JPG" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                  <div class="card-body">
                    <p class="card-text text-center">ຮູບພາບ </p>
                  </div>
                </div>
              </div> -->
            </div>
          </div>

        </section>
        <!-- ພາກສ່ວນຊົມລົມເຕັ້ນ -->
        
    <section id="dance" class="portfolio">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <img src="../../assetss/img/dance.jpeg" alt="" style="width: 10rem; height: 10rem;">
          <h3><span>ຊົມລົມເຕັ້ນ</span></h3>
        </div>
        <div class="row">
          <div class="col-sm-12 my-1">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">
                  ບໍ່ມີການເຄື່ອນໄຫວ
                </h5>
              </div>
            </div>
          </div>
        </div>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/dance/d1.jpeg" target="_blank">
                <img src="../../assetss/img/dance/d1.jpeg" alt="" class="mx-2"
 mb-2"
  style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div> -->
        </div>
      </div>
    </section>
        <!-- ພາກສ່ວນຊົມລົມດົນຕຣີ -->
        <section id="music" class="portfolio">
          <div class="container" data-aos="fade-up">

            <div class="section-title">
              <img src="../../assetss/img/music/images.png" alt="" style="width: 10rem; height: 10rem;">
              <h3><span>ຊົມລົມດົນຕຣີ</span></h3>
            </div>
            <div class="row">
              <div class="col-sm-12 my-1">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title"></h5>
                    <h4>
                      ບໍ່ມີການເຄື່ອນໄຫວ 
                    </h4>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 my-1">
           <!--  <div class="card">
              <div class="card-body">
                 <div class="col-lg-12 my-3" data-aos="fade-right" data-aos-delay="100">
                  <video width="100%" height="100%" controls autoplay muted>
                    <source src="../../assetss/img/music/" type="video/mp4" border="2">
                    <source src="../../assetss/img/music/" type="video/ogg">
                  </video>
                </div>
              </div>
            </div> -->
          </div> 
            </div>
            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

              <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/music/ms1.JPG" target="_blank">
                    <img src="../../assetss/img/music/ms1.JPG" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                  <div class="card-body">
                    <p class="card-text text-center">ຮູບພາບ </p>
                  </div>
                </div>
              </div> -->
            </div>
          </div>
        </section>
        <!-- ພາກສ່ວນຊົມລົມແຕ້ມ -->
        <section id="drawing" class="portfolio">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <img src="../../assetss/img/drawing.jpeg" alt="" style="width: 12rem; height: 10rem;">
          <h3><span>ຊົມລົມແຕ້ມຮູບ</span></h3>
        </div>
        <div class="row">
          <div class="col-sm-12 my-1">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title"></h5>
                <h4>
                  ບໍ່ມີການເຄື່ອນໄຫວ
                </h4>
              </div>
            </div>
          </div>
          <div class="col-sm-6 my-1">
            <!-- <div class="card">
              <div class="card-body">
                 <div class="col-lg-12 my-3" data-aos="fade-right" data-aos-delay="100">
                  <video width="100%" height="100%" controls autoplay muted>
                    <source src="../../assetss/videos/2.mp4" type="video/mp4" border="2">
                    <source src="../../assetss/videos/2.mp4" type="video/ogg">
                  </video>
                </div> 
              </div>
            </div> -->
          </div>
        </div>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/drawing/d1.JPG" target="_blank">
                <img src="../../assetss/img/drawing/d1.JPG" alt="" class="mx-2 mb-2"
                 style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
        </div> -->

      </div>

    </section>
        <!-- ພາກສ່ວນຊົມລົມໂຕ້ວາທີ -->
        <section id="PD" class="portfolio">
          <div class="container" data-aos="fade-up">

            <div class="section-title">
              <img src="../../assetss/img/D-P.jpeg" alt="" style="width: 10rem; height: 10rem;">
              <h3><span>ຊົມລົມຖ່າຍຮູບແລະໂຕ້ວາທີ</span> </h3>
            </div>
            <div class="row">
              <div class="col-sm-12 my-1">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title"></h5>
                    <h4>
                      ບໍ່ມີການເຄື່ອນໄຫວ
                    </h4>
                  </div>
                </div>
              </div>
              <!-- <div class="col-sm-6 my-1">
            <div class="card">
              <div class="card-body">
                <div class="col-lg-12 my-3" data-aos="fade-right" data-aos-delay="100">
                  <video width="100%" height="100%" controls autoplay muted>
                    <source src="../../assetss/videos/4.mp4" type="video/mp4" border="2">
                    <source src="../../assetss/videos/4.mp4" type="video/ogg">
                  </video>
                </div> 
              </div>
            </div>
          </div> -->
            </div>
            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

              <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/photography/ca1.JPG" target="_blank">
                    <img src="../../assetss/img/photography/ca1.JPG" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                  <div class="card-body">
                    <p class="card-text text-center">ຮູບພາບ </p>
                  </div>
                </div>
              </div> -->

            </div>
          </div>
        </section>
        <!-- ພາກສ່ວນຊົມລົມບານເຕະ -->
        <section id="football" class="team section-bg" style="background:none">

          <div class="container" data-aos="fade-up">

            <div class="section-title">
              <img src="../../assetss/img/football.jpeg" alt="" style="width: 12rem; height: 10rem;">
              <h3 style="font-family: 'Noto Sans Lao', sans-serif;
              font-weight: 600;"><span>ຊົມລົມກິລາບານເຕະ</span></h3>
            </div>
            <div class="row">
              <div class="col-sm-12 my-1">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title"> ບໍ່ມີການເຄື່ອນໄວ</h5>
                  </div>
                </div>
              </div>
              <!-- <div class="col-sm-6 my-1">
            <div class="card">
              <div class="card-body">
                <div class="col-lg-12 my-3" data-aos="fade-right" data-aos-delay="100">
                  <video width="100%" height="100%" controls autoplay muted>
                    <source src="../../assetss/videos/6.mp4" type="video/mp4" border="2">
                    <source src="../../assetss/videos/6.mp4" type="video/ogg">
                  </video>
                </div>
              </div>
            </div>
          </div> -->
            </div>
            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

               <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/sport/football/f1.jpg" target="_blank">
                    <img src="../../assetss/img/sport/football/f1.jpg" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                  <div class="card-body">
                    <p class="card-text text-center">ຮູບພາບ </p>
                  </div>
                </div>
              </div>  -->
          </div>

        </section>
        <!-- ພາກສ່ວນຊົມລົມບານສົ່ງ -->
        <section id="volleyball" class="team section-bg" style="background:none">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <img src="../../assetss/img/volleyball.jpeg" alt="" style="width: 10rem; height: 10rem;">
          <h3 style="font-family: 'Noto Sans Lao', sans-serif;
              font-weight: 600;"><span>ຊົມລົມກິລາບານສົ່ງ</span></h3>

        </div>

        <div class="row">
          <div class="col-sm-12 my-1">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">
                  ບໍ່ມີການເຄື່ອນໄຫວ
                </h5>       
              </div>
            </div>
          </div>
        </div>
         <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <!-- <div class="card my-1 mx-1" style="width: 21rem;">
              <a href="../../assetss/img/sport/volleyball/v1.jpg" target="_blank">
                <img src="../../assetss/img/sport/volleyball/v1.jpg" alt="" class="mb-2"
                            style="width:315px; height:200px; margin-top: 15px;">
              </a>
            </div> -->
          </div>
        </div> 
      </div>

    </section>
        <!-- ພາກສ່ວນຊົມລົມບານບ້ວງ -->
        <section id="basketball" class="team section-bg" style="background:none">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <img src="../../assetss/img/basketball.jpeg" alt="" style="width: 10rem; height: 10rem;">
          <h3 style="font-family: 'Noto Sans Lao', sans-serif;
              font-weight: 600;"><span>ຊົມລົມກິລາບານບ້ວງ</span></h3>
        </div>

        <div class="row">
          <div class="col-sm-12 my-1">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">
                  ບໍ່ມີການເຄື່ອນໄຫວ
                </h5>
              </div>
            </div>
          </div>
          <div class="col-sm-6 my-1">
            <!-- <div class="card">
              <div class="card-body">
               <div class="col-lg-12 my-3" data-aos="fade-right" data-aos-delay="100">
                  <video width="100%" height="100%" controls autoplay muted>
                    <source src="../../assetss/videos/5.mp4" type="video/mp4" border="2">
                    <source src="../../assetss/videos/5.mp4" type="video/ogg">
                  </video>
                </div>
              </div>
            </div> -->
        </div>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="card my-2 mx-2" style="width: 21rem;">
              <a href="../../assetss/img/sport/basketball/b1.jpeg" target="_blank">
                <img src="../../assetss/img/sport/basketball/b1.jpeg" alt="" cl mb-2"
                            style="width:315px; height:200px; margin-top: 15px;">
              </a>
              
            </div>
          </div> -->
        </div>
      </div>
      </div>

        <!-- haakkeo sound crew -->

        <section id="Haakkeo Sound Crew" class="portfolio">
        <div class="container" data-aos="fade-up">

          <div class="section-title">
            <img src="../../assetss/img/create_sound.jpeg" alt="" style="width: 10rem; height: 10rem;">
            <h3><span>Haakkeo Sound Crew</span></h3>
          </div>
          <div class="row">
            <div class="col-sm-12 my-1">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title"></h5>
                  <p>
                    ບໍ່ມີການເຄື່ອນໄຫວ
                  </p>
                </div>
              </div>
            </div>

            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

              <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/haakkeo sound crew/SC1.jpg" target="_blank">
                    <img src="../../assetss/img/haakkeo sound crew/SC1.jpg" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                  <div class="card-body">
                    <p class="card-text text-center">ຮູບພາບ </p>
                  </div>
                </div>
              </div> -->

            </div>
      </section>
    <!-- ພາກສ່ວນຄົນດີຮຽນເກັ່ງ -->
     <section id="m6" class="pricing">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h3><span>ຄົນດີຮຽນເກັ່ງ</span></h3>
        </div>
        <p>
        </p>
        <div class="row">
          <div class="col-sm-12 my-1">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">
                  <p> ນັກຮຽນທີຊະນະເລີດການແຕ້ມຮູບGrand prix Arteorks Gallery Mitsubishi Asian Children's  :</p>
                </h5>
                <p class="card-text">
                <ol type="">
                  <li>ທ.ອານັນໄຊ ນໍ່ແກ້ວ(ປີໂປ້) ໄດ້ລາງວັນທີ 1</li>
                  <li>ນ. ສຸພາວะດີ ແກ້ວສະຫວ່າງ(ນ້ຳໜຶ່ງ) ລາງວັນຊົມເຊີຍ</li>
                </ol>
                </p>
               <!--  <a href="../../assetss/img/goodstudy/g1.jpeg" target="_blank">
                  <video width="50%" height="50%" controls autoplay muted>
                    <source src="../../assetss/videos/VDO 1.mp4" type="video/mp4" border="2">
                    <source src="../../assetss/videos/VDO 1.mp4" type="video/ogg">
                  </video>
                </a> -->
              </div>
            </div>
          </div>
          <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

              <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/goodstudy/g1.jpg" target="_blank">
                    <img src="../../assetss/img/goodstudy/g1.jpg" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/goodstudy/g2.jpg" target="_blank">
                    <img src="../../assetss/img/goodstudy/g2.jpg" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/goodstudy/g3.jpg" target="_blank">
                    <img src="../../assetss/img/goodstudy/g3.jpg" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/goodstudy/g4.jpg" target="_blank">
                    <img src="../../assetss/img/goodstudy/g4.jpg" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/goodstudy/g5.jpg" target="_blank">
                    <img src="../../assetss/img/goodstudy/g5.jpg" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="card my-1 mx-1" style="width: 21rem;">
                  <a href="../../assetss/img/goodstudy/g6.jpg" target="_blank">
                    <img src="../../assetss/img/goodstudy/g6.jpg" alt="" class="mx-2"
                      style="width:315px; height:200px; margin-top: 15px;">
                  </a>
                </div>
              </div>

          </div>
        </div>
      </div>
    </section>
    <!-- ພາກສ່ວນການຕິດຕໍ່ -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h3 style="font-family: 'Noto Sans Lao', sans-serif;
              font-weight: 600;"><span>ການຕິດຕໍ່</span></h3>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-6">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3 style="font-family: Noto sans lao,sans-serif;">ທີຢູ່ມຂອງພວກເຮົາ</h3>
              <p> ບ້ານ ທົ່ງກາງ, ຮ່ອມ 11, ເມຶອງ ສີສັດຕະນາກ, ເເຂວງ ນະຄອນຫຼວງວຽງຈັນ</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box mb-4">
              <i class="bx bx-envelope"></i>
              <h3 style="font-family: Noto sans lao,sans-serif;">ອີເມວ</h3>
              <p>Haakkeo.school@gamil.com</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box mb-4">
              <i class="bx bx-phone-call"></i>
              <h3 style="font-family: Noto sans lao,sans-serif;">ເບີໂທ</h3>
              <p>021 315772</p>
            </div>
          </div>

        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-6 ">
            <iframe class="mb-4 mb-lg-0"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3795.959666010427!2d102.62373071488406!3d17.934035087753177!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xd25bd5d231f7a827!2zMTfCsDU2JzAyLjUiTiAxMDLCsDM3JzMzLjMiRQ!5e0!3m2!1sen!2sla!4v1661758542079!5m2!1sen!2sla"
              frameborder="0" style="border:0; width: 100%; height: 384px;" allowfullscreen=""></iframe>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box mb-4">
              <i class="bx bxl-whatsapp"></i>
              <h3 style="font-family: Noto sans lao,sans-serif;">Whatapps</h3>
              <a href="http://wa.me/5589 5588" target="_blank">
                <p>021 315772</p>
              </a>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="info-box mb-4">
              <i class="bx bxl-facebook"></i>
              <h3 style="font-family: Noto sans lao,sans-serif;">Web Page</h3>
              <a href="https://www.facebook.com/people/Haakkeo-Eshlj-Thongkang/100008421045224/">
                <p>Haakkeo Eshji Thongkang</p>
              </a>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>Haakeo New</span></strong>. All Rights
        Reserved
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center
      justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../../assetss/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../../assetss/vendor/aos/aos.js"></script>
  <script src="../../assetss/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../../assetss/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../../assetss/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../../assetss/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../../assetss/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="../../assetss/vendor/php-email-form/validate.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="../../assetss/datatables.net/js/jquery.dataTables.min.js"></script>
  <!-- Template Main JS File -->
  <script src="../../assetss/js/main.js"></script>
    <script>
      ClassicEditor
          .create( document.querySelector( '.editor' ) )
          .catch( error => {
              console.error( error );
          } );
    </script>
</body>

</html><?php /**PATH D:\Devlopment\WebApplication\resources\views/Home.blade.php ENDPATH**/ ?>